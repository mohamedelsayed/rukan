-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 15, 2016 at 12:14 AM
-- Server version: 5.5.53
-- PHP Version: 5.6.23-1+deprecated+dontuse+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rukan`
--

-- --------------------------------------------------------

--
-- Table structure for table `academics`
--

CREATE TABLE IF NOT EXISTS `academics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `tab_title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `body` longtext CHARACTER SET utf8,
  `image` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `academics`
--

INSERT INTO `academics` (`id`, `title`, `tab_title`, `body`, `image`, `approved`, `created`, `updated`) VALUES
(1, 'Test 1', 'Upper', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', '4image005_cf143.jpg', 1, '2015-11-06 19:37:05', '2015-11-06 19:37:05'),
(2, 'Test 2', 'Middle', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'image025_d9bd5.jpg', 1, '2015-11-06 19:40:20', '2015-11-06 19:40:20'),
(3, 'Test 3', 'Lower', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', '2image003_df790.jpg', 1, '2015-11-06 19:40:56', '2015-11-06 19:40:56');

-- --------------------------------------------------------

--
-- Table structure for table `agreements`
--

CREATE TABLE IF NOT EXISTS `agreements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_type` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `agree_flag` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE IF NOT EXISTS `albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keywords` text NOT NULL,
  `header` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `albums`
--

INSERT INTO `albums` (`id`, `title`, `meta_description`, `meta_keywords`, `header`, `created`, `updated`, `approved`) VALUES
(10, '<p>\r\n	Discovery City Trip</p>\r\n', '', '', '', '2016-03-30 13:15:28', '2016-11-14 23:59:35', 1),
(11, '<p>\r\n	Alexandria Trip</p>\r\n', '', '', '', '2016-04-04 14:25:56', '2016-11-14 23:58:48', 1),
(12, '<p>\r\n	Sports Day</p>\r\n', '', '', '', '2016-05-03 11:20:54', '2016-11-14 23:57:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE IF NOT EXISTS `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` longtext,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `title_ar` varchar(255) DEFAULT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `date` datetime NOT NULL,
  `header` text NOT NULL,
  `header_ar` text,
  `body` longtext NOT NULL,
  `body_ar` longtext,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `shared` int(11) NOT NULL DEFAULT '0',
  `like` int(11) NOT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `creator` varchar(255) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `title_ar`, `meta_keywords`, `meta_description`, `date`, `header`, `header_ar`, `body`, `body_ar`, `created`, `updated`, `hits`, `shared`, `like`, `featured`, `approved`, `creator`, `tags`) VALUES
(2, 'Parent Orientation', 'تست 2', '', '', '2015-11-09 09:00:00', '', 'تست 2 تست 2', '<p>\r\n	Parents were welcomed to our school for an Academic Orientation with Ms. Amira Sowelem and Ms. Mai Mossad. They took a tour around school and were introduced to our teaching staff.</p>\r\n', '<p>\r\n	تست 2 تست 2</p>\r\n', '2015-11-03 01:10:25', '2015-12-21 13:07:50', 50, 0, 0, 0, 1, '', ''),
(3, 'Learning Difficulties Workshop', NULL, '', '', '2015-11-06 16:01:00', '', NULL, '<p>\r\n	<span style="font-size:18px;">This workshop has been delivered by Mrs. Reham El Mellawani. She is a certified educational psychologist and has opened and developed the Learning Support Dept in two of the leading international schools in Egypt.&nbsp;</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', NULL, '2015-11-08 04:03:27', '2015-12-21 13:09:40', 63, 0, 0, 0, 1, NULL, NULL),
(5, 'Health Awareness Week', NULL, '', '', '2015-11-16 08:00:00', '', NULL, '<div>\r\n	The aim of the Health Awareness Campaign was to promote healthy eating, being active, learning about where food comes from and</div>\r\n<div>\r\n	introduce healthy cooking concepts. In their classes, pupils learned about nutritional facts, how to be fit, how to make healthy choices and the importance of being healthy. Moreover, we held a competition throughout the week for who brought the healthiest lunchbox.</div>\r\n', NULL, '2015-12-08 11:07:07', '2015-12-21 13:09:06', 34, 0, 0, 0, 1, NULL, NULL),
(6, 'FS-1/2 & KS-1/2 December Trips', NULL, '', '', '2015-12-10 11:08:00', '', NULL, '<p>\r\n	This month is full of trips! An arrangement for FS pupils has been made for them to go to the Giza Zoo where they will enjoy interacting with animals and be introduced to academic concepts they have studied. As for our Key Stage pupils, they will be going on a field trip to Wadi Environmental Science Center (WESC) for emphasis on specific academic concepts introduced in their curriculums.</p>\r\n', NULL, '2015-12-15 11:28:04', '2015-12-21 13:07:10', 151, 0, 0, 0, 1, NULL, NULL),
(7, 'EIS vs. CIS Football Match', NULL, '', '', '2016-01-20 11:30:00', '', NULL, '<p>\r\n	Not only are our PE lessons full of fun and friendly competition, we also assembled our very first team for the sport of football. Last week, our school team was invited for a match with City International School pupils. On the match day, our pupils were welcomed on the CIS campus with Ethosians winning by a single point ending the match with a score of 7-6.</p>\r\n', NULL, '2016-02-22 12:39:41', '2016-02-22 12:39:41', 137, 0, 0, 0, 1, NULL, NULL),
(8, 'EIS vs. MHS Football Match', NULL, '', '', '2016-02-01 11:30:00', '', NULL, '<p>\r\n	<span style="color: rgb(20, 24, 35); font-family: helvetica, arial, sans-serif; font-size: 14px; line-height: 19.32px;">Today, we hosted a soccer game where we welcomed the Manor House soccer team to our school premises. With a wonderful spirit and a friendly manner, the match ended with a score of 4-2 to Manor House pupils. Well, who needs to keep count when you&#39;ve made new friends and worthy opponents? We certainly don&#39;t!</span></p>\r\n', NULL, '2016-02-22 13:50:54', '2016-02-22 13:50:54', 155, 0, 0, 0, 1, NULL, NULL),
(9, 'Open Day', NULL, '', '', '2016-02-08 10:00:00', '', NULL, '<p>\r\n	We are hosting our Open Days and school tours for the new academic year 2016/2017.</p>\r\n', NULL, '2016-02-22 13:54:04', '2016-02-22 13:54:04', 204, 0, 0, 0, 1, NULL, NULL),
(10, 'International Day', NULL, '', '', '2016-02-11 09:00:00', '', NULL, '<p>\r\n	<span style="color: rgb(20, 24, 35); font-family: helvetica, arial, sans-serif; font-size: 14px; line-height: 19.32px;">For two weeks, each year group chose a country and learnt all about it; its language, food, traditional clothes and other details pertaining to that country. On the last day, our pupils came in their country&#39;s costumes and showcased them in a lovely parade. Moreover, work that was produced throughout the week was displayed in and out of their classrooms. Parents were thrilled to see their child(ren) take part in such an event. We are as thrilled to have such amazing pupils be part of the Ethos community. Learning is not just about books; we are committed to the creative learning process.</span></p>\r\n', NULL, '2016-02-22 14:01:18', '2016-02-22 14:01:18', 175, 0, 0, 0, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE IF NOT EXISTS `attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `downloads` int(11) NOT NULL DEFAULT '0',
  `node_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `attend_events`
--

CREATE TABLE IF NOT EXISTS `attend_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `attend_flag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `audios`
--

CREATE TABLE IF NOT EXISTS `audios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `hits` int(11) NOT NULL,
  `album_id` int(11) NOT NULL,
  `header` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blocked_members`
--

CREATE TABLE IF NOT EXISTS `blocked_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `blocked_member_id` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `careers`
--

CREATE TABLE IF NOT EXISTS `careers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `to_email` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `careers`
--

INSERT INTO `careers` (`id`, `title`, `description`, `to_email`, `created`, `updated`, `approved`, `weight`) VALUES
(1, 'Computing Teacher', '<p>\r\n	We are seeking to hire a committed and enthusiastic full-time teacher of ICT to teach Foundation Stages 1 &amp; 2 and Key Stages 1 &amp; 2. This post is suitable for either a newly or qualified or experienced teacher with the emphasis on the computing element.</p>\r\n', 'hr@ethosedu.com', '2015-11-20 00:21:47', '2015-11-26 12:18:10', 1, 1),
(2, 'Art Teacher', '<p>\r\n	For educators who are excited to join a forward-thinking, well-resourced and highly productive and creative Art Department, we are seeking to hire a full-time multi-skilled Art teacher for our Foundation and Key Stage 1 &amp; 2 pupils with an excellent track record and a strong understanding of curriculum opportunities and development.</p>\r\n', 'hr@ethosedu.com', '2015-11-20 00:26:08', '2015-12-21 12:52:20', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL DEFAULT '#000000',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `color`, `approved`, `created`, `updated`, `weight`) VALUES
(1, 'Sports', '#009933', 1, '2015-11-11 05:58:06', '2015-11-26 11:29:49', 0),
(2, 'Holiday', '#ff0033', 1, '2015-11-11 05:58:30', '2015-11-26 11:30:03', 0),
(3, 'Academic', '#3300ff', 1, '2015-11-11 21:44:02', '2015-11-26 11:30:15', 0),
(4, 'Open Day', '#00cccc', 1, '2015-11-11 21:44:26', '2015-11-26 11:30:40', 0),
(5, 'Trips', '#6633cc', 1, '2015-11-11 21:44:46', '2015-11-26 11:30:49', 0),
(6, 'Parents Day', '#cc9966', 1, '2015-11-25 08:05:20', '2015-11-26 11:31:10', 0),
(7, 'Other', '#660000', 0, '2015-11-26 11:29:37', '2015-11-26 11:29:37', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cats`
--

CREATE TABLE IF NOT EXISTS `cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `cat_type` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT '0',
  `date` date NOT NULL,
  `under_construction` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) DEFAULT '0',
  `has_url` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `pdf_file` varchar(255) DEFAULT NULL,
  `to_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `cats`
--

INSERT INTO `cats` (`id`, `title`, `body`, `image`, `meta_keywords`, `meta_description`, `cat_type`, `parent_id`, `date`, `under_construction`, `approved`, `created`, `updated`, `weight`, `has_url`, `url`, `pdf_file`, `to_email`) VALUES
(1, 'About', '', '', '', '', 0, NULL, '2014-04-05', 0, 1, '0000-00-00 00:00:00', '2015-11-23 11:34:49', 1, 0, '', NULL, NULL),
(2, 'Admissions', '', '', '', '', 0, NULL, '0000-00-00', 0, 1, '2014-04-20 19:11:51', '2015-11-09 20:15:47', 2, 0, '', NULL, NULL),
(3, 'Education', '', '', '', '', 0, NULL, '0000-00-00', 0, 1, '2014-04-20 19:12:30', '2015-11-09 20:17:25', 3, 0, '', NULL, NULL),
(4, 'Student Life', '', '', '', '', 0, NULL, '0000-00-00', 0, 0, '2014-04-21 15:08:32', '2016-11-14 21:52:00', 4, 0, '', '', NULL),
(5, 'Calendar', '', '', '', '', 0, NULL, '0000-00-00', 0, 1, '2014-04-21 15:09:09', '2015-11-11 04:02:33', 5, 1, '/calendar', NULL, NULL),
(6, 'Media', '', '', '', '', 0, NULL, '0000-00-00', 0, 1, '2014-04-21 15:09:35', '2015-11-09 20:19:31', 6, 0, '', NULL, NULL),
(7, 'Contact Us', '', '', '', '', 0, NULL, '0000-00-00', 0, 1, '2014-04-21 15:10:11', '2015-11-24 01:36:58', 10, 1, '/contact-us', NULL, NULL),
(8, 'Rukan Nursery', '', '', '', '', 0, NULL, '0000-00-00', 0, 0, '2014-04-21 15:10:43', '2015-11-23 11:18:46', 8, 1, 'http://google.com.eg/', NULL, NULL),
(9, 'Careers', '', '', '', '', 0, NULL, '0000-00-00', 0, 1, '2014-04-21 15:11:04', '2015-11-26 12:38:53', 9, 0, '', NULL, NULL),
(10, 'News', '', '', '', '', 0, 6, '0000-00-00', 0, 1, '2015-11-09 20:23:39', '2015-11-09 20:23:39', 1, 1, '/article/all', NULL, NULL),
(11, 'Gallery', '', '', '', '', 0, 6, '0000-00-00', 0, 1, '2015-11-09 20:24:14', '2015-11-09 20:24:14', 2, 1, '/gallery/all', NULL, NULL),
(12, 'About Us', '<h2>\r\n	<span style="font-size:16px;">Get to know Ethos International School (EIS)</span></h2>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	We are a private international school in Egypt offering a first class British education. &nbsp;Our main aim is to offer future generations a holistic education that provides development opportunities, intellectual exposure and varied experiences, while maintaining and supporting healthy social norms.&nbsp;Established in 2015, the school occupies 2.5 acres of land in Sheikh Zayed City with a green, environmentally friendly campus.&nbsp;Once completed, the campus will contain a total of 56 classes with a maximum of 25 pupils per class; all classes are equipped with smart boards and air conditioners.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Additionally, the school campus will offer a swimming pool, a squash court, a football court and a multi-purpose basketball court. The first phase of the campus has already been built and occupies 1000 square meters of land with 40 rooms servicing 350 pupils and 150 staff members. Apart from the classrooms, the campus holds a library, computer lab, music room and art room.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>EIS is committed to GREEN</strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; The campus is built on non-agricultural desert land.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; All classrooms have been built facing the North, which allows for maximum natural lighting and ventilation.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; Wide windows allow maximum natural lighting and ventilation.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; All windows are double glazed to minimize noise pollution and thermal exchange.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; All lighting systems use LED units to reduce electric energy consumption.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; Fifty percent of the school&rsquo;s electricity is generated by solar energy.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; All water used for flushing tanks and watering plants is recycled water.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; All faucets are sensor enabled.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; All drinkable water is filtered.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; Playground areas are equipped with artificial turf to reduce water consumption.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&bull; All trees, flowers, bushes and shrubs planted on campus will produce fruits and/or pleasant aromas.</p>\r\n<p style="margin-left:32.2pt;">\r\n	&nbsp;</p>\r\n<p style="margin-left:32.2pt;">\r\n	&nbsp;</p>\r\n<p>\r\n	Delivering the UK National Curriculum program, EIS accepts pupils starting in Foundation Stage 1 up to Year 6. By 2020, we will have completed all phases of the school premises and will start to deliver the full IGCSE programme. By 2022, we will be operating up to Year 12 and can offer A level courses to our pupils. Our programme meets the needs of pupils planning on higher education, whether in Egypt or abroad, and is further enhanced by Arabic, Religion and Social Studies courses to meet the requirements of the Egyptian Ministry of Education.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	At Ethos, we support diversity among our staff members. We believe that all children have the basic right to deal with educators who can serve as role-models. Believing that professional development is of vital importance, all of our staff go through intensive in-training&nbsp;programmes in all aspects of teaching and learning throughout the year.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', 'about_pic_97016_a5c14.jpg', '', '', 0, 1, '0000-00-00', 0, 1, '2015-11-11 22:22:20', '2016-04-20 15:25:45', 0, 0, '', '', NULL),
(13, 'Message from Director', '<p>\r\n	Dear Parents,</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<img alt="" src="/app/webroot/img/ckeditor/IMG_5315(1).jpg" style="width: 150px; float: right; height: 223px;" /></p>\r\n<p>\r\n	I would like to take this opportunity to welcome both yourselves and your children to the EIS community. It was in response to the needs of the community that our school was established, with the continuous encouragement and support of many parents, who shared our vision of what a school should be. It is having this common vision that drives us forward.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	<strong>&ldquo;To become the benchmark for educational facilities in the region; providing academic excellence and integrity for responsible and productive global citizens&rdquo;</strong></h3>\r\n<div>\r\n	<p>\r\n		<img alt="MD Note (2).jpg (5024×2948)" src="file:///C:/Users/Markting/Desktop/Ethos%20Docs/Website/Website%20Photos/MD%20Note%20(2).jpg" /></p>\r\n	<p>\r\n		<img alt="MD Note (2).jpg (5024×2948)" src="file:///C:/Users/Markting/Desktop/Ethos%20Docs/Website/Website%20Photos/MD%20Note%20(2).jpg" /><img alt="MD Note (2).jpg (5024×2948)" src="file:///C:/Users/Markting/Desktop/Ethos%20Docs/Website/Website%20Photos/MD%20Note%20(2).jpg" />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n	<h4>\r\n		The school&rsquo;s vision has been built on three main pillars:</h4>\r\n	<p style="margin-left: 32.2pt;">\r\n		&nbsp;</p>\r\n	<p style="margin-left: 32.2pt;">\r\n		&nbsp;</p>\r\n	<p style="margin-left: 32.2pt;">\r\n		&bull;&nbsp;The<strong>&nbsp;first pillar</strong>&nbsp;is Character Education which is an integrated programme that aims to develop in our pupils, core ethical and moral values to help them become caring and responsible individuals.</p>\r\n	<p style="margin-left: 32.2pt;">\r\n		&nbsp;</p>\r\n	<p style="margin-left: 32.2pt;">\r\n		&bull;&nbsp;The&nbsp;<strong>second pillar</strong>&nbsp;is our quality of education which offers our pupils the skills and knowledge they need to become a competent workforce and productive citizens.</p>\r\n	<p style="margin-left: 32.2pt;">\r\n		&nbsp;</p>\r\n	<p style="margin-left: 32.2pt;">\r\n		&bull;&nbsp;The&nbsp;<strong>third pillar</strong>&nbsp;is our Arabic Studies Department. Its main purpose is to maintain our culture and educate our pupils about our identity in order to create well-rounded human beings.</p>\r\n	<div>\r\n		<div>\r\n			<p>\r\n				&nbsp;</p>\r\n			<div>\r\n				<p>\r\n					&nbsp;</p>\r\n				<p style="margin-left:54pt;">\r\n					&nbsp;</p>\r\n				<p style="margin-left:54pt;">\r\n					&nbsp;</p>\r\n				<p>\r\n					Sincerely,</p>\r\n				<p>\r\n					Muhammad Salah</p>\r\n			</div>\r\n			<p>\r\n				&nbsp;</p>\r\n		</div>\r\n		<p>\r\n			&nbsp;</p>\r\n	</div>\r\n	<p>\r\n		&nbsp;</p>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', 0, 1, '0000-00-00', 0, 1, '2015-11-11 22:50:09', '2016-02-23 10:06:34', 2, 0, '', '', NULL),
(14, 'Mission/Vision', '<h3>\r\n	Our Philosophy</h3>\r\n<p>\r\n	We believe that a solid education at school level is based on a rigorous, engaging curriculum supported by a framework of vital 21st century skills, with a system of moral principles at its core, and a code of values governing the conduct of all stakeholders.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	Vision</h3>\r\n<p>\r\n	To become the benchmark for educational facilities in the region; providing academic excellence and integrity for responsible and productive global citizens.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	Mission Statement</h3>\r\n<p>\r\n	To offer a British education while maintaining social norms and local culture. We believe that every child deserves an equal educational opportunity; working tirelessly to:</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Prepare devoted, responsible pupils</p>\r\n<p>\r\n	&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Provide parents with the&nbsp; support necessary to help their children develop optimally</p>\r\n<p>\r\n	&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Minimize carbon print and negative environmental effects</p>\r\n<p>\r\n	&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Provide a healthy, safe working and learning environment</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	Values</h3>\r\n', 'shutterstock_267442394_39c0c.jpg', '', '', 0, 1, '0000-00-00', 0, 1, '2015-11-13 00:48:40', '2016-02-21 12:31:11', 3, 0, '', '', NULL),
(15, 'History', '<div>\r\n	<img alt="" src="/app/webroot/img/ckeditor/Picture1(2).jpg" style="text-align: right; width: 280px; height: 159px; float: right;" /></div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	In 2010, Ethos for Educational Services management team established Rukan, a preschool facility that was located in Sheikh Zayed City. The main philosophy of this establishment at the time was to create a caring and nurturing environment to help develop children holistically.</div>\r\n<div>\r\n	<div>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			After thorough consideration of the market needs and with our loyal parents&rsquo; support, we established Ethos International School (EIS) in January 2014. EIS is funded by an investment company managed by Ethos for Educational Services and&nbsp;aims to provide a British education merging high educational standards with an ethical base and a clear</p>\r\n		<p>\r\n			identity.</p>\r\n		<p>\r\n			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n		<p>\r\n			<img alt="" src="/app/webroot/img/ckeditor/History.jpg" style="width: 400px; float: right;" /></p>\r\n		<p>\r\n			We started our first academic year in September 2014 on the Rukan campus. Now, with our persistence and motivation, the first phase of the EIS building is complete and by 2020, the entire school premises will be complete.</p>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			&nbsp;</p>\r\n	</div>\r\n	<p>\r\n		&nbsp;</p>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', 0, 1, '0000-00-00', 0, 1, '2015-11-13 00:51:12', '2016-02-23 10:07:13', 4, 0, '', '', NULL),
(16, 'Testimonials', '', '', '', '', 0, 1, '0000-00-00', 0, 0, '2015-11-13 00:52:00', '2015-12-02 10:21:47', 5, 0, '', NULL, NULL),
(17, 'Accreditation', '<p>\r\n	The school delivers the UK National Curriculum program and has acquired its accreditation from Cambridge International Examinations. EIS is currently a British Council attached school with the Cambridge International Examination (CIE) accreditation.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<img alt="" src="/app/webroot/img/ckeditor/british-council-logo-2-color-2-page-001-hr.jpg" style="height: 115px; width: 400px;" /></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<img alt="" src="/app/webroot/img/ckeditor/logo-cie.jpg" style="width: 600px;" /></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', 0, 1, '0000-00-00', 0, 1, '2015-11-13 00:53:41', '2016-02-22 12:16:09', 6, 0, '', '', NULL),
(18, 'Governance', '<p>\r\n	The main role of Ethos International School&#39;s governing body is to provide strategic leadership and work with the head teacher and staff to ensure our school provides premium quality education and continues to strive for excellence through supporting, promoting and monitoring learning and learning outcomes.</p>\r\n', '', '', '', 0, 1, '0000-00-00', 0, 0, '2015-11-13 00:54:23', '2015-11-23 13:22:04', 7, 0, '', NULL, NULL),
(19, 'Who''s Who?', '<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', 0, 1, '0000-00-00', 0, 1, '2015-11-13 00:55:43', '2015-12-01 12:40:07', 8, 0, '', NULL, NULL),
(20, 'Facilities', '<h2>\r\n	Library<img alt="" src="/app/webroot/img/ckeditor/DSC_5655.jpg" style="font-size: 14px; width: 400px; float: right;" /></h2>\r\n<p>\r\n	Classified by the Dewey Decimal System, our libraries cover significant space and include all genres of books. Our pupils have the liberty to choose books either for leisure or academic use.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h2>\r\n	Science Labs</h2>\r\n<p>\r\n	Science laboratories are state of the art and are equipped with science equipment, internet, and projectors for all Key Stage pupils; they are also monitored by full-time technicians to ensure safety.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h2>\r\n	<strong>Clinic</strong></h2>\r\n<p>\r\n	The school provides a well-equipped clinic for all pupils. The school doctor and nurses have relevant experience and cater to pupils with injuries or illnesses and keep medical files.</p>\r\n<div>\r\n	&nbsp;</div>\r\n<p>\r\n	&nbsp;</p>\r\n<h2>\r\n	<img alt="" src="/app/webroot/img/ckeditor/Facilities 2(1).jpg" style="font-size: 12px; font-weight: normal; width: 350px; float: right;" /></h2>\r\n<h2>\r\n	Football and Other Courts</h2>\r\n<div>\r\n	<div>\r\n		<p>\r\n			Our Physical Education curriculum offers a wide range&nbsp;of sport activities, using our Football field and our multi-purpose, hard surface court. Pupils are also encouraged to take part in school teams and compete in school tournaments. School courts are used extensively during the school day and for after-school activities. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n		<div>\r\n			<p>\r\n				&nbsp;</p>\r\n			<p>\r\n				&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n			<h2>\r\n				Pool</h2>\r\n			<p>\r\n				An indoor pool will enable many sports opportunities to be enjoyed throughout the year, regardless of adverse weather conditions. We are keen to help children learn the basic fundamentals of swimming during PE class and assure parents that their children are having a safe aquatic experience.</p>\r\n			<p>\r\n				&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n			<h2>\r\n				<strong>Theater</strong></h2>\r\n			<p>\r\n				Our versatile and flexible theatre hosts events, from drama workshops to productions and quizzes. It is designated to the development and creativity of our pupils, where they can produce, direct and act and create unforgettable drama productions.</p>\r\n			<p>\r\n				&nbsp;</p>\r\n			<div>\r\n				<h2>\r\n					<strong>Prayer Room and Multi-faith Room</strong></h2>\r\n				<p>\r\n					Designated areas for students who wish to pray during break times.</p>\r\n			</div>\r\n			<p>\r\n				&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n			<img alt="" src="/app/webroot/img/ckeditor/Facilities 3(1).jpg" style="width: 300px; float: right;" />\r\n			<h2>\r\n				<strong>Computer Lab</strong></h2>\r\n		</div>\r\n		<div>\r\n			<br />\r\n			<div>\r\n				<p>\r\n					With full-time operating internet connectivity, our Computer lab is designed to support our pupils&#39; interactive learning through access to online workbooks and worksheets. The school system will be operated by our IT technicians and support facilities.&nbsp;</p>\r\n				<div>\r\n					<p>\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n					<p>\r\n						&nbsp;</p>\r\n					<h2>\r\n						<strong>Squash Court</strong></h2>\r\n				</div>\r\n			</div>\r\n			<div>\r\n				<div>\r\n					<p>\r\n						Encouraging students to excel at squash in the school glass backed court, which is also used during Physical Education classes.</p>\r\n					<p>\r\n						&nbsp;</p>\r\n					<p>\r\n						&nbsp;</p>\r\n					<h2>\r\n						<strong>Cafeteria&nbsp;</strong></h2>\r\n					<p>\r\n						We believe that the quality of food highly affects a child&#39;s behaviour, performance and learning ability, consequently the offerings of the school cafeteria promote health and proper nutrition.</p>\r\n				</div>\r\n				<div>\r\n					<img alt="" src="/app/webroot/img/ckeditor/DSC_5669(1).jpg" style="width: 350px; float: right;" /></div>\r\n				<div>\r\n					<br />\r\n					<p>\r\n						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n					<h2>\r\n						<strong>Playgrounds</strong></h2>\r\n				</div>\r\n				<div>\r\n					&nbsp;</div>\r\n				<div>\r\n					<p>\r\n						Our school playgrounds are designed with respect to physical ability, age and developmental appropriateness, and sensory-stimulating activity to provide a safe environment for a play setting.</p>\r\n					<div>\r\n						&nbsp;</div>\r\n					<h2>\r\n						&nbsp;</h2>\r\n				</div>\r\n				<p>\r\n					&nbsp;</p>\r\n			</div>\r\n			<p>\r\n				&nbsp;</p>\r\n		</div>\r\n		<p>\r\n			&nbsp;</p>\r\n	</div>\r\n	<p>\r\n		&nbsp;</p>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'Facilities_BIG_0372c.jpg', '', '', 0, 1, '0000-00-00', 0, 1, '2015-11-13 00:57:22', '2016-02-18 09:57:44', 9, 0, '', '', NULL),
(21, 'Admissions Procedures', '<h3>\r\n	&nbsp;</h3>\r\n<h3>\r\n	A very warm welcome to our prospective applicants!</h3>\r\n<p>\r\n	Because we &nbsp;want to ensure an easy and smooth admission process, it is with the utmost diligence that our Admissions Team goes through each and every application starting from its initial phase. At Ethos, we encourage parents to visit us on campus prior to the application process. This can be done by contacting the school via email or telephone for an appointment.&nbsp;</p>\r\n<h1>\r\n	Steps for the application process:</h1>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;1. Complete our <a href="http://ethos.mohamedelsayed.net/page/show/2/23" target="_blank">Online Application Form</a>. (one per child)</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2. Schedule an appointment with our Admissions Office for a parent interview and a child assessment.&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h2>\r\n	What happens next?</h2>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; 3. Make sure to submit two previous progress report cards by email or hard copy to our Admissions Office.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; 4. Upon acceptance, please provide the following documents to our registrar:</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;- 12 passport-sized photos of your child.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;- Child electronic original birth certificate.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;- Parents&#39; IDs or passports.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;- Copy of Vaccination Report.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;- Copies of report cards from previous schools (if applicable).</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;- Transfer documents stamped by &quot;Idara Ta&#39;alimeya&quot; if applicable (not for FS1 applicants).</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;- &quot;Bayan Nagah&quot; from the &quot;Idara Ta&#39;alimeya&quot; if applicable.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	* Fees are available to view on the EIS campus.</h3>\r\n<p>\r\n	&nbsp;</p>\r\n<h2>\r\n	Contact Details</h2>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	EIS Address: 20/6 behind Royal City Compound, Sheikh Zayed City, Egypt.</p>\r\n<p>\r\n	Telephone: 01028966660 -&nbsp;01028966663</p>\r\n<p>\r\n	email: admission@ethosedu.com</p>\r\n<p style="margin-left:72.0pt;">\r\n	&nbsp;</p>\r\n<p style="margin-left:72.0pt;">\r\n	&nbsp;</p>\r\n<p style="margin-left:72.0pt;">\r\n	&nbsp;</p>\r\n<p style="margin-left:72.0pt;">\r\n	&nbsp;</p>\r\n<p style="margin-left:72.0pt;">\r\n	&nbsp;</p>\r\n<p style="margin-left:72.0pt;">\r\n	&nbsp;</p>\r\n', '', '', '', 0, 2, '0000-00-00', 0, 1, '2015-11-13 01:42:04', '2016-02-22 08:44:55', 1, 0, '', '', NULL),
(22, 'Policies & Useful Information', '<h2>\r\n	Junior School</h2>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The Junior School consists of three Key Stages for pupils from ages 4 to12.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<table border="1" cellpadding="1" cellspacing="1" style="width: 300px">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				<strong>Academic Stage</strong></td>\r\n			<td>\r\n				<strong>Year Group</strong></td>\r\n			<td>\r\n				<strong>Age</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				<strong>Foundation Stage</strong></td>\r\n			<td>\r\n				FS1</td>\r\n			<td>\r\n				4-5</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				&nbsp;</td>\r\n			<td>\r\n				FS2</td>\r\n			<td>\r\n				5-6</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				<strong>Key Stage 1</strong></td>\r\n			<td>\r\n				Year 1</td>\r\n			<td>\r\n				6-7</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				&nbsp;</td>\r\n			<td>\r\n				Year 2</td>\r\n			<td>\r\n				7-8</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				<strong>Key Stage 2</strong></td>\r\n			<td>\r\n				Year 3</td>\r\n			<td>\r\n				8-9</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				&nbsp;</td>\r\n			<td>\r\n				Year 4</td>\r\n			<td>\r\n				9-10</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				&nbsp;</td>\r\n			<td>\r\n				Year 5</td>\r\n			<td>\r\n				10-11</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				&nbsp;</td>\r\n			<td>\r\n				Year 6</td>\r\n			<td>\r\n				11-12</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	&nbsp;</p>\r\n<h2>\r\n	General Information</h2>\r\n<table border="1" cellpadding="1" cellspacing="1" style="width: 500px">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				<strong>Position</strong></td>\r\n			<td>\r\n				<strong>Name</strong></td>\r\n			<td>\r\n				<strong>E-mail Address</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				General Manager</td>\r\n			<td>\r\n				Muhammad Salah</td>\r\n			<td>\r\n				muhammadsalah@ethosedu.com</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Deputy General Manager</td>\r\n			<td>\r\n				Youssra Raafat</td>\r\n			<td>\r\n				youssraraafat@ethosedu.com</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Head Teacher</td>\r\n			<td>\r\n				Amira Sowelem</td>\r\n			<td>\r\n				amirasowelem@ethosedu.com</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Foundation Stage Head</td>\r\n			<td>\r\n				Mai Mosaad</td>\r\n			<td>\r\n				maimossad@ethosedu.com</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Character Education Head</td>\r\n			<td>\r\n				Nohha Emad</td>\r\n			<td>\r\n				nohhaemad@ethosedu.com</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Arabic Studies Head</td>\r\n			<td>\r\n				Amira Gomaa</td>\r\n			<td>\r\n				amirali@ethosedu.com</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Marketing &amp; BD Specialist</td>\r\n			<td>\r\n				Shadden El Banna</td>\r\n			<td>\r\n				marketing@ethosedu.com</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Admissions Department</td>\r\n			<td>\r\n				Alya Mansour</td>\r\n			<td>\r\n				admission@ethosedu.com</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Finance Department</td>\r\n			<td>\r\n				Mona Morsy</td>\r\n			<td>\r\n				finance@ethosedu.com</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				HR Department</td>\r\n			<td>\r\n				Iman Elarabi</td>\r\n			<td>\r\n				hr@ethosedu.com</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', 0, 2, '0000-00-00', 0, 1, '2015-11-13 01:43:00', '2016-02-22 08:47:12', 2, 0, '', '', NULL),
(23, 'Online Admission Form', '', '', '', '', 0, 2, '0000-00-00', 0, 1, '2015-11-13 01:43:31', '2016-02-18 14:59:34', 3, 0, '', '', 'admission@ethosedu.com'),
(24, 'Foundation Stage', '<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	The Foundation Stage at Ethos offers the &ldquo;Early Years Foundation Stage&quot; (EYFS) Framework&nbsp;set by the UK Department of Education.</h3>\r\n<p>\r\n	It promotes both teaching and learning and ensures that pupils are ready for their Junior Years. It also gives pupils a broad range of knowledge and skills for good future progress through school and prepares them for entry to Key Stage 1.</p>\r\n<h3>\r\n	&nbsp;</h3>\r\n<h3>\r\n	The four guiding principles that shape this framework are:</h3>\r\n<p>\r\n	&nbsp;</p>\r\n<ul>\r\n	<li>\r\n		Every child is a unique child, who is constantly learning and can be resilient, capable, confident and self-assured.</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<ul>\r\n	<li>\r\n		Children learn to be strong and independent through positive relationships.</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<ul>\r\n	<li>\r\n		Children learn and develop well in enabling environments, in which their experiences respond to their individual needs and there is a strong partnership between practitioners and parents and/or carers.</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<ul>\r\n	<li>\r\n		Children develop and learn in different ways and at different rates. The framework covers the education and care of all children using a multisensory approach, and differentiated activities to ensure that every child&rsquo;s learning needs are being met.</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Our Foundation Stage is located in a self-contained building on campus, which is fully equipped with colourful furnishings and stimulating resources. This building also has its own bathroom facilities, library, art room, music room and extensive space, both indoors and outdoors.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The Foundation Stage is a crucial time in a child&#39;s academic journey, it is a time of rapid growth, where pupils are developing physically, intellectually, emotionally and socially, and at EIS we give this stage all the focus and dedication it needs.</p>\r\n', 'Foundation_Stage_ad663.jpg', '', '', 0, 3, '0000-00-00', 0, 1, '2015-11-13 01:59:06', '2016-02-18 14:50:43', 1, 0, '', '', NULL),
(25, 'Junior School', '<h3>\r\n	Key Stages 1 &amp; 2 teaching and learning are supported by a variety of premium quality resources and are planned in accordance with the UK National Curriculum.&nbsp;</h3>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Our junior school section covers a broad range of subjects including, English, Mathematics, and Science, in addition to other topics that will foster pupil&rsquo;s knowledge and understanding of the world such as History, Geography and cross-cultural topics. Our curriculum also includes more subjects such as Art &amp; Design, Music, PE and Computing.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Through a well-structured framework set by the UK Department of Education, junior school pupils develop their academic skills. These skills are complemented by reading, writing, listening and interacting. We believe that it is at this age that the love of reading takes root and then flourishes throughout the years; therefore, we have a large library to help children progress in reading and to complement the reading requirements set out in the framework.</p>\r\n<p>\r\n	&nbsp;&nbsp;</p>\r\n<p>\r\n	Our junior pupils&#39; classrooms are spacious, colourful and vibrant. They are located in a separate building on the school premises and have their own facilities including bathrooms, a computing lab and outdoor play areas.</p>\r\n<p>\r\n	&nbsp;</p>\r\n', 'Junior_School_dc094.jpg', '', '', 0, 3, '0000-00-00', 0, 1, '2015-11-13 02:00:37', '2016-02-21 09:12:50', 2, 0, '', '', NULL),
(26, 'Senior/Secondary School', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', '', '', '', 0, 3, '0000-00-00', 0, 0, '2015-11-13 02:01:22', '2015-12-02 10:15:20', 3, 0, '', NULL, NULL),
(27, 'Arabic Studies', '<h3>\r\n	EIS follows the Egyptian Ministry of Education Arabic requirements.</h3>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	All Egyptian pupils will be taking Arabic and Religion starting Foundation Stage and Arabic Social Studies starting Year 4.&nbsp; As of Year 1, pupils are assessed internally on a termly basis.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Ministry exams for all year groups are scheduled by the Ministry of Education and are usually held in January and May. In Year 6, pupils will sit the Ministry exam to receive their certification.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', 'Arabic_Studies_fcf9c.jpg', '', '', 0, 3, '0000-00-00', 0, 1, '2015-11-13 02:02:11', '2016-02-18 10:23:55', 4, 0, '', '', NULL),
(28, 'Art & Music', '<h2>\r\n	Art &amp; Music</h2>\r\n<p>\r\n	<span style="font-size:16px;">Expressive arts, such as drama, music, drawing, painting and handicrafts, enable children to explore and play with&nbsp;a&nbsp;wide range of media and materials, as well as providing opportunities and encouragement for sharing thoughts, ideas and feelings through a variety of activities in art, music, movement, dance and role-play.</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<img alt="" src="/app/webroot/img/ckeditor/IMG_0743.jpg" style="width: 400px; height: 362px; float: right;" /></p>\r\n<p>\r\n	We encourage our pupils to explore their own creativity and to theoretically and practically design and deliver expressive arts in a variety of surrounding circumstances. Among the curricular objectives is being able to perform for an audience and have the confidence to present in public.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h4>\r\n	The National Curriculum for Art &amp; Design aims to ensure that all pupils:</h4>\r\n<p>\r\n	- Produce creative work, exploring their ideas and recording their experience.</p>\r\n<p>\r\n	- Become proficient in drawing, painting, sculpture and other art, craft and design techniques.</p>\r\n<p>\r\n	- Evaluate and analyse creative works using the language of art, craft and design.</p>\r\n<p>\r\n	- Know about great artists, craft makers and designers, and understand the historical and cultural development of their art forms.&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h4>\r\n	The National Curriculum framework for Music aims to ensure that all pupils:</h4>\r\n<p>\r\n	- Perform, listen to, review and evaluate music across a range of historical periods, genres, styles and traditions, including the works of the great composers and musicians.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	- Learn to sing and to use their voices, to create and compose music on their own and with others, have the opportunity to learn a musical instrument, use technology appropriately and have the opportunity to progress to the next level of musical excellence.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	- Understand and explore how music is created, produced and communicated, including through the inter-related dimensions: pitch, duration, dynamics, tempo, timbre, texture, structure and appropriate musical notations.&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	We also believe Music is not only an enjoyable subject but&nbsp;also one that can enrich pupils&#39; lives and education. Music learning increases craftsmanship, increases coordination and helps build imagination and intellectual curiosity.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', 0, 4, '0000-00-00', 0, 1, '2015-11-13 02:09:52', '2016-02-25 09:00:35', 1, 0, '', '', NULL),
(29, 'Music', '<h2 style="text-align: justify;">\r\n	Music</h2>\r\n<h2 style="text-align: justify;">\r\n	<img alt="" src="/app/webroot/img/ckeditor/Music.jpg" style="float: right; width: 400px;" /></h2>\r\n<p>\r\n	<span style="font-size:16px;">We believe Music is not only an enjoyable subject bu</span><span style="font-size: 16px;">t&nbsp;</span><span style="font-size: 16px;">also one that can enrich pupils&#39; lives a</span><span style="font-size: 16px;">nd education. Music learning increases craftsmanship, increases coordination and helps build imagination and intellectual curiosity. </span></p>\r\n<p style="text-align: justify;">\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size: 16px;">The National Curriculum framework for music aims to ensure that all pupils:</span></p>\r\n<p style="text-align: justify;">\r\n	&nbsp;</p>\r\n<p>\r\n	&middot; Perform, listen to, review and evaluate music across a range of historical &nbsp;periods, genres, styles and traditions, including the works of the great &nbsp;composers and musicians</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&middot; Learn to sing and to use their voices, to create and compose music on their &nbsp;own and with others, have the opportunity to learn a musical instrument, use &nbsp;technology appropriately and have the opportunity to progress to the next &nbsp;level of musical excellence.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p style="text-align: justify;">\r\n	&middot; Understand and explore how music is created, produced and communicated, including through the inter-related dimensions: pitch, &nbsp;duration, dynamics, tempo, timbre, texture, structure and appropriate musical notations.&nbsp;</p>\r\n<p style="text-align: justify;">\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', 0, 4, '0000-00-00', 0, 0, '2015-11-13 02:10:26', '2016-02-18 10:52:51', 2, 0, '', '', NULL),
(30, 'Sports', '<h2>\r\n	Sports</h2>\r\n<p>\r\n	<span style="font-size: 16px;">At EIS, sports play a very crucial role, by which we offer our pupils&nbsp;</span><span style="font-size: 16px;">a wide range of activities and sports during the school day as well as during after-school activities.</span></p>\r\n<h1>\r\n	<span style="font-size: 16px;">The National Curriculum framework for Physical Education aims to:</span></h1>\r\n<div>\r\n	<h2>\r\n		<img alt="" src="/app/webroot/img/ckeditor/Sports.jpg" style="font-size: 12px; font-weight: normal; float: right; width: 500px;" /></h2>\r\n</div>\r\n<div>\r\n	<span style="font-size: 16px;">- Help pupils develop fundamental skills, become increasingly co</span><span style="font-size: 16px;">mpetent and confident and access&nbsp;</span><span style="font-size: 16px;">a broad range of opportunities to extend their agili</span><span style="font-size: 16px;">ty, balance and coordination, individually and with others.</span></div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	<span style="font-size: 16px;">-</span>&nbsp;Enable pupils to enjoy communicating, collaborating and competing&nbsp;with each other.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	- Enable pupils to develop an understanding of how to&nbsp;improve in different physical activities and sports and learn how&nbsp;to evaluate and recognise their own success.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	<div>\r\n		&nbsp;</div>\r\n	<pre>\r\n\r\n\r\n\r\n\r\n\r\n</pre>\r\n	<div>\r\n		&nbsp;</div>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', 0, 4, '0000-00-00', 0, 1, '2015-11-13 02:11:12', '2016-02-22 12:19:04', 3, 0, '', '', NULL),
(31, 'School Houses', '<h2>\r\n	School Houses</h2>\r\n<div>\r\n	<h2>\r\n		<img alt="" src="/app/webroot/img/ckeditor/IMG_5171.JPG" style="float: right; width: 450px;" /></h2>\r\n	<div>\r\n		<p>\r\n			It is traditional in British Schools to operate a &lsquo;House System&rsquo;. This is a friendly competition between pupils and staff and involves pupils from all Year Groups working together to accumulate points for their House. All pupils and staff are assigned to one of EIS&#39; four Houses; Knights, Gladiators, Samurais and Musketeers.</p>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			The House System is an essential component to the development of our school spirit and covers various sports and competitions and is also a way to enourage Positive Behaviour Interventions and Support (PBIS).</p>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			<strong>Positive Behaviour Policy:</strong></p>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			We believe that providing a nurturing, safe and caring environment which encourages and fosters positive attitudes will enable students to develop appropriate social skills and be active and welcomed members of society. At EIS we believe in reinforcing positive behaviour and providing space and time for self- reflection and awareness.</p>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			<strong>In this regard parent &ndash; school cooperation is vital for reinforcing the Five Golden Rules:</strong></p>\r\n		<p>\r\n			&nbsp;</p>\r\n		<p>\r\n			- We believe in honesty</p>\r\n		<p>\r\n			- We believe in responsibility</p>\r\n		<p>\r\n			- We encourage respect</p>\r\n		<p>\r\n			- We value cooperation</p>\r\n		<p>\r\n			- We encourage safety</p>\r\n	</div>\r\n</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&nbsp;</div>\r\n', '', '', '', 0, 4, '0000-00-00', 0, 1, '2015-11-13 02:12:09', '2016-02-18 11:37:05', 4, 0, '', '', NULL),
(32, 'Events & Trips', '<h2>\r\n	Events &amp; Trips</h2>\r\n<p>\r\n	&nbsp;</p>\r\n<h2 dir="rtl">\r\n	<img alt="" src="/app/webroot/img/ckeditor/Events &amp; Trips.jpg" style="font-size: 12px; width: 420px; float: right;" /></h2>\r\n<p>\r\n	EIS recognizes the importance of events for the educational, social and moral development of children. School trips and events are integral parts of the curriculum and extensions of learning in the classroom. They are designed to stimulate pupil interest by connecting learning with experiences outside of the classroom&nbsp;environment.&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Trips can be sports related, historical, cultural, for scientific purposes or of a&nbsp;geographic interest. Trips can either take place during the school day or may require pupils to stay somewhere on an overnight basis. All pupils attend at least 2 day trips throughout the year and KS 2 have one overnight trip planned into their academic year.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', 0, 4, '0000-00-00', 0, 1, '2015-11-13 02:12:39', '2016-02-22 12:18:16', 5, 0, '', '', NULL),
(33, 'Character Education', '<h2>\r\n	Character Education</h2>\r\n<p>\r\n	<img alt="" src="/app/webroot/img/ckeditor/Character Education(1).jpg" style="height: 526px; width: 1000px;" /></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>&quot;If you work with or around pupils, you cannot not be a character educator.&quot; Abstaining is not an option&quot; (Damon, 2002).</strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The aim of our Character Education Program is to develop in all pupils&rsquo; core ethical and moral values in order to help pupils become caring, responsible and contributing citizens. Character education includes a broad range of educational approaches such as whole pupil education, service learning, social-emotional learning, civic education and aims to promote a core set of universally acknowledged values. Character Education involves all stakeholders and must be a visible and conscious part of our school culture. All staff members play a critical role in enforcing these values across the school; classrooms, playgrounds, corridors, bathrooms, buses etc. Teachers are responsible for integrating the values into the school curriculum and daily lesson plans. Pupils focus on one specific value each month. Skills needed to effectively practice and apply each value are taught during the Character Education weekly lessons.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', 0, 4, '0000-00-00', 0, 1, '2015-11-13 02:13:18', '2016-02-18 11:35:16', 6, 0, '', '', NULL),
(34, 'Vacancies', '<p>\r\n	You can fill an application by clicking the Apply Now button.</p>\r\n', '', '', '', 0, 9, '0000-00-00', 0, 1, '2015-11-13 02:16:00', '2015-11-20 23:56:50', 1, 1, '/career/all/vacancies', NULL, NULL),
(35, 'Continuous Professional Development', '<p>\r\n	Our Continuous Professional Development Programme for teachers, is guided mainly by the School Improvement Plan and the individual needs of the staff within the school.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	We integrate multiple approaches in our school&rsquo;s professional development programme. First, we offer intensive in-service training in the form of workshops that foster acquisition of new skills and knowledge in different areas in the field of education through direct instruction and participatory activities. Case studies are used in the workshop approach to encourage teachers to think through a situation and develop alternative solutions to the problem posed in the case studies. In addition, reflective practice is used which is the actual observation of instruction (i.e., by video); and then collegially reflecting on ways either to improve the practice observed.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Secondly, through formal and informal observations and on the job mentoring and coaching which has proven to be one of the most successful ways of developing skills, expertise and confidence. Staff members are also given verbal and written feedback when observed, and have the opportunity for peer observation, as this is an effective way to develop best practices across the school.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Third, we have programs that involve teachers in inquiry and conducting research that requires teachers to reflect upon their daily practices in a systematic, intentional manner, over time.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Finally, engaging teachers in curriculum development and later in program enhancement, and program improvement.</p>\r\n<p>\r\n	Our workshops are categorized under Teaching and Learning and Classroom Management and Personality Traits. We offered different hands on workshops where teachers were given opportunities to construct their own learning and have space to practice what they learnt.&nbsp;</p>\r\n', '', '', '', 0, 9, '0000-00-00', 0, 1, '2015-11-13 02:16:45', '2015-11-26 12:41:01', 2, 1, '/career/all/developments', NULL, NULL),
(36, 'Tuition Fees', '<h3 class="adders_foundation">\r\n	Tuition Fees 2015-2016</h3>\r\n<table border="1" cellpadding="1" cellspacing="1" style="width: 500px;">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				Year</td>\r\n			<td>\r\n				Age</td>\r\n			<td>\r\n				Tuition Fees</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Preschool</td>\r\n			<td>\r\n				2y/10m</td>\r\n			<td>\r\n				25,000</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Foundation Stage 1</td>\r\n			<td>\r\n				3y/10m</td>\r\n			<td>\r\n				38,000</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Foundation Stage 2</td>\r\n			<td>\r\n				4y/10m</td>\r\n			<td>\r\n				38,000</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Year 1</td>\r\n			<td>\r\n				5y/10m</td>\r\n			<td>\r\n				44,500</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Year 2</td>\r\n			<td>\r\n				6y/10m</td>\r\n			<td>\r\n				45,500</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Year 3</td>\r\n			<td>\r\n				7y/10m</td>\r\n			<td>\r\n				50,000</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Year 4</td>\r\n			<td>\r\n				8y/10m</td>\r\n			<td>\r\n				51,000</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				Year 5</td>\r\n			<td>\r\n				9y/10m</td>\r\n			<td>\r\n				52,000</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	&nbsp;</p>\r\n<p style="text-align: center;">\r\n	&nbsp;* All fees are paid in Egyptian Pounds (EGP)</p>\r\n<h3 class="adders_foundation">\r\n	Installment payments: April - July - November</h3>\r\n<p>\r\n	All fees exclude: Tests and books.</p>\r\n<p>\r\n	Assessment Fees: EGP 500</p>\r\n<p>\r\n	Registration Fees: EGP 5,000</p>\r\n', '', '', '', 0, 2, '0000-00-00', 0, 0, '2015-11-17 22:39:23', '2015-12-02 12:06:09', 4, 0, '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `article_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `map_iframe` longtext,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `facebook_link` varchar(255) DEFAULT NULL,
  `linkedin_link` varchar(255) DEFAULT NULL,
  `working_hours` text,
  `inner_title` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `zoom` int(11) NOT NULL DEFAULT '17',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `title`, `body`, `map_iframe`, `address`, `phone`, `mail`, `facebook_link`, `linkedin_link`, `working_hours`, `inner_title`, `latitude`, `longitude`, `zoom`) VALUES
(1, 'Contact Us', '<p>\r\n	<span style="font-size:24px;">Contact Details</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:16px;"><strong>Address:</strong> </span>20/6 behind Royal City Compound, Sheikh Zayed City, Egypt.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	<span style="font-size:16px;"><strong>Mobile Numbers:</strong></span></h3>\r\n<p>\r\n	01028966660</p>\r\n<p>\r\n	01028966663</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Email:</strong> info@ethosedu.com</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>General Departments:</strong></p>\r\n<p>\r\n	admission@ethosedu.com</p>\r\n<p>\r\n	finance@ethosedu.com</p>\r\n<p>\r\n	hr@ethosedu.com</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d1726.7967341989813!2d30.990038671900187!3d30.048518805670664!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sar!2seg!4v1448323659808" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>', '20/6 behind Royal City compound, Sheikh Zayed City, Cairo', '(+2) 01028966660', 'info@ethosedu.com', 'https://www.facebook.com/ethosinternationalschool', 'http://www.linkedin.com/LCEofficial', '<p>\r\n	Sunday-Thursday: 10am to 10pm<br />\r\n	Friday: 3pm to 9pm<br />\r\n	Satuday: Closed</p>\r\n', 'Send us a message', '30.0394841769706', '31.0238777489319', 14);

-- --------------------------------------------------------

--
-- Table structure for table `developments`
--

CREATE TABLE IF NOT EXISTS `developments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `body` text,
  `image` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `developments`
--

INSERT INTO `developments` (`id`, `title`, `sub_title`, `body`, `image`, `created`, `updated`, `weight`, `approved`) VALUES
(2, 'Classroom Centers', 'Training & Workshops', '<p>\r\n	<span style="font-size:12px;"><span style="color: rgb(51, 51, 51); font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; line-height: 20px;">A learning center is a self-contained section of the classroom in which students engage in independent and self-directed learning activities. They&nbsp;</span><span style="color: rgb(51, 51, 51); font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; line-height: 20px;">give teachers the opportunity to focus on specific areas of study and adhere to learning interaction between pupils.&nbsp;</span></span>Centers help in creating effective classroom centers that help and facilitate the delivery of the learning objectives.</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '20151109022338_2f1c5.jpg', '2015-11-20 06:58:53', '2015-12-07 14:31:11', 2, 1),
(3, 'Guided Reading', 'Training & Workshops', '<p>\r\n	Guided reading is the bridge between shared (group) reading and independent reading. It allows teachers to help pupils make the transition from teacher modelling to pupils&#39; independence. In guided reading, the teacher scaffolds the learning of a small group of pupils as they apply strategies previously taught during read-alouds and shared reading to an unfamiliar, but carefully selected, text. This text is within the pupils&#39; instructional range and provides reasonable challenges for learning. The teacher supports the pupils as they talk, read, and think their way through a text using effective reading strategies. While the teacher works with a guided reading group, the rest of the class engages in independent activities. From the first few weeks of school, the teacher provides many opportunities for pupils to practice learning center routines before working independently in small groups.</p>\r\n', 'IMG_5036.JPG_73868.jpg', '2015-11-20 06:59:24', '2015-12-07 10:55:46', 3, 1),
(4, 'Jolly Phonics', 'Training & Workshops', '<p>\r\n	It is a comprehensive 2 day programme that provides optimum coverage of theory and practice in teaching Phonics. The entire course is based on Jolly Phonics Methodology and is delivered by professional Jolly Phonics trainers accredited by Jolly Learning Ltd of UK, the original developers of the Jolly Phonics Methodology. The workshop covers topics that are essential for every teacher.&nbsp;At Ethos we use the Jolly Phonics program; which has a fun and child centered approach to teaching literacy through synthetic phonics. With actions for each of the 42 letter sounds, the multi-sensory method is very motivating for children. The sounds are taught in a specific order (not alphabetically). This enables children to begin building words as early as possible.</p>\r\n', '20151109022819_95161.jpg', '2015-11-20 06:59:49', '2015-12-07 14:31:03', 1, 1),
(5, 'Emergency First Response', 'Trainings & Workshops', '<p>\r\n	Our PE staff have attended the Emergency First Response training. The training aims to provide rescuers with the tools needed to perform life support and first aid when faced with any medical emergency.<span style="font-size:14px;">&nbsp;<span style="font-size:12px;"><span style="color: rgb(36, 36, 36); font-family: ''Source Sans Pro'', sans-serif; line-height: 24.2857px;">This course allows participants to learn, practice and apply emergency care skills specific to helping infants and children with medical emergencies. It&rsquo;s designed for those who work with children or are likely to have to respond to emergencies involving youngsters. This course is often integrated with Primary Care (CPR) and Secondary Care (First Aid) courses.</span></span></span></p>\r\n', 'Emergency_First_Response_d0fe8.jpg', '2015-12-07 10:30:06', '2015-12-07 14:31:24', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `timing` time NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `agenda` longtext,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `from_date`, `to_date`, `timing`, `location`, `agenda`, `member_id`, `created`, `updated`, `approved`, `category_id`) VALUES
(33, '<p>\r\n	End of Term</p>\r\n', '2017-06-30', '2017-06-30', '08:00:00', '', '', 0, '2015-11-26 10:05:06', '2016-11-15 00:08:57', 1, 2),
(34, '<p>\r\n	Parents Day</p>\r\n', '2017-07-05', '2017-07-05', '08:00:00', '', '', 0, '2015-11-30 10:30:10', '2016-11-15 00:08:35', 1, 6),
(61, '<p>\r\n	Reports In</p>\r\n', '2017-06-12', '2017-06-12', '08:00:00', '', '', 0, '2016-06-01 10:50:49', '2016-11-15 00:09:10', 1, 3),
(62, '<p>\r\n	Parents Day</p>\r\n', '2017-06-28', '2017-06-28', '08:00:00', '', '', 0, '2016-06-01 10:51:14', '2016-11-15 00:09:03', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE IF NOT EXISTS `faqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `forum_comments`
--

CREATE TABLE IF NOT EXISTS `forum_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` longtext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `attachement` varchar(255) DEFAULT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `post_id` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `gals`
--

CREATE TABLE IF NOT EXISTS `gals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caption` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `node_id` int(11) NOT NULL DEFAULT '0',
  `content_id` int(11) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `article_id` int(11) NOT NULL DEFAULT '0',
  `album_id` int(11) NOT NULL DEFAULT '0',
  `cover` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=353 ;

--
-- Dumping data for table `gals`
--

INSERT INTO `gals` (`id`, `caption`, `image`, `node_id`, `content_id`, `position`, `article_id`, `album_id`, `cover`) VALUES
(13, '', 'IMG_5313_1_.JPG_9e982.jpg', 0, 0, 0, 3, 0, 0),
(17, '', '92_0034c.jpg', 0, 0, 0, 5, 0, 0),
(18, '', 'IMG_5059.JPG_24835.jpg', 0, 0, 0, 2, 0, 0),
(227, '', 'IMG_5906.JPG_9aa93.jpg', 0, 0, 0, 6, 0, 0),
(317, '', 'IMG_0343.JPG_8f4bd.jpg', 0, 0, 0, 7, 0, 0),
(318, '', 'IMG_0470.JPG_3b703.jpg', 0, 0, 0, 8, 0, 0),
(319, '', 'open_day_invitation_2016_72px_e2c00.jpg', 0, 0, 0, 9, 0, 0),
(320, '', 'IMG_1186.JPG_c8287.jpg', 0, 0, 0, 10, 0, 0),
(350, '', '/2016/11/1479160648pic_rukan_home.jpg', 0, 0, 0, 0, 12, 1),
(351, '', '/2016/11/2image001.jpg', 0, 0, 0, 0, 11, 0),
(352, '', '/2016/11/2image003.jpg', 0, 0, 0, 0, 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `logos`
--

CREATE TABLE IF NOT EXISTS `logos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `weight` int(11) DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `role` int(11) NOT NULL DEFAULT '2',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `block_posts_notification` tinyint(1) NOT NULL DEFAULT '0',
  `block_comments_notification` tinyint(1) NOT NULL DEFAULT '0',
  `block_announcements_notification` tinyint(1) NOT NULL DEFAULT '0',
  `block_events_notification` tinyint(1) NOT NULL DEFAULT '0',
  `confirm_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `newsletters`
--

CREATE TABLE IF NOT EXISTS `newsletters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_name` varchar(255) DEFAULT NULL,
  `from_email` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nodes`
--

CREATE TABLE IF NOT EXISTS `nodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `teaser` text NOT NULL,
  `body` longtext NOT NULL,
  `viewed` int(11) NOT NULL DEFAULT '0',
  `created` date NOT NULL,
  `updated` date NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `cat_id` int(11) NOT NULL DEFAULT '0',
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `date` date NOT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `participants` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT '0',
  `top_image` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` longtext,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(355) DEFAULT NULL,
  `attachement` varchar(255) DEFAULT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `queues`
--

CREATE TABLE IF NOT EXISTS `queues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `newsletter_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `quotes`
--

CREATE TABLE IF NOT EXISTS `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `body` text,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `footer` varchar(255) NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `file_types` varchar(255) NOT NULL,
  `image_types` varchar(255) NOT NULL,
  `max_upload_size` int(11) NOT NULL,
  `resize` int(1) NOT NULL,
  `max_image_width` int(11) NOT NULL,
  `master_image_width` int(11) NOT NULL,
  `master_image_height` int(11) NOT NULL,
  `large_image_width` int(11) NOT NULL,
  `large_image_height` int(11) NOT NULL,
  `medium_image_width` int(11) NOT NULL,
  `medium_image_height` int(11) NOT NULL,
  `thumb_width` int(11) NOT NULL,
  `thumb_height` int(11) NOT NULL,
  `video_width` int(11) NOT NULL,
  `video_height` int(11) NOT NULL,
  `limit` int(11) NOT NULL DEFAULT '0',
  `google_analytics_propertyid` varchar(255) NOT NULL,
  `audio_width` int(11) NOT NULL,
  `audio_height` int(11) NOT NULL,
  `facbook_link` varchar(255) DEFAULT NULL,
  `linkedin_link` varchar(255) DEFAULT NULL,
  `youtube_link` varchar(255) DEFAULT NULL,
  `twitter_link` varchar(255) DEFAULT NULL,
  `google_plus_link` varchar(255) DEFAULT NULL,
  `contact_us_email` varchar(255) NOT NULL,
  `paging_limit` int(11) NOT NULL DEFAULT '12',
  `minimum_year` int(11) NOT NULL,
  `maximum_year` int(11) NOT NULL,
  `newsletter_limit` int(11) NOT NULL,
  `return_path_email` varchar(255) NOT NULL,
  `comment_paging_limit` int(11) NOT NULL DEFAULT '0',
  `home_string` varchar(255) NOT NULL,
  `blog_string` varchar(255) NOT NULL,
  `faq_string` varchar(255) NOT NULL,
  `faq_fotter_string` varchar(255) NOT NULL,
  `maintenance_mode` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance_mode_text` text,
  `testimonial_cut_string` int(11) NOT NULL DEFAULT '0',
  `article_cut_string` int(11) NOT NULL DEFAULT '0',
  `article_cut_string_inner` int(11) NOT NULL DEFAULT '0',
  `gallary_paging_limit` int(11) NOT NULL DEFAULT '0',
  `carrers_paging_limit` int(11) NOT NULL DEFAULT '0',
  `carrers_developments_paging_limit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `url`, `email`, `title`, `footer`, `meta_keywords`, `meta_description`, `file_types`, `image_types`, `max_upload_size`, `resize`, `max_image_width`, `master_image_width`, `master_image_height`, `large_image_width`, `large_image_height`, `medium_image_width`, `medium_image_height`, `thumb_width`, `thumb_height`, `video_width`, `video_height`, `limit`, `google_analytics_propertyid`, `audio_width`, `audio_height`, `facbook_link`, `linkedin_link`, `youtube_link`, `twitter_link`, `google_plus_link`, `contact_us_email`, `paging_limit`, `minimum_year`, `maximum_year`, `newsletter_limit`, `return_path_email`, `comment_paging_limit`, `home_string`, `blog_string`, `faq_string`, `faq_fotter_string`, `maintenance_mode`, `maintenance_mode_text`, `testimonial_cut_string`, `article_cut_string`, `article_cut_string_inner`, `gallary_paging_limit`, `carrers_paging_limit`, `carrers_developments_paging_limit`) VALUES
(1, 'http://www.ethosedu.com', 'rukan@mohamedelsayed.net', 'Rukan', '© All Copyrights Reserved. 2016', '', '', 'zip,rar,pdf,doc,docx,flv,mp3,xls,xlsx,ppt,pptx', 'jpeg,jpg,gif,png', 2000, 4, 2000, 800, 500, 705, 342, 385, 250, 250, 250, 500, 300, 80, 'UA-73581303-1', 400, 27, 'https://www.facebook.com/EthosInternationalSchool/', 'http://www.linkedin.com/', 'http://www.youtube.com/', 'http://twitter.com/', 'http://plus.google.com/', 'lce@mohamedelsayed.net', 4, 1900, 2020, 100, 'ethos@mohamedelsayed.net', 10, 'Home', 'Blog', 'FAQS', 'FAQS in coaching', 0, '<p style="text-align: center;">\r\n	&nbsp;</p>\r\n<p style="text-align: center;">\r\n	This is site in Maintenance Mode.</p>\r\n', 30, 13, 20, 9, 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `slideshows`
--

CREATE TABLE IF NOT EXISTS `slideshows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `target` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE IF NOT EXISTS `subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `job` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `name`, `email`, `phone`, `job`, `created`, `updated`, `sent`, `user_id`) VALUES
(1, NULL, 'me@mohamedelsayed.net', NULL, NULL, '2015-11-21 09:25:33', '2015-11-21 09:25:33', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE IF NOT EXISTS `team_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `biography` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`id`, `name`, `position`, `biography`, `image`, `mail`, `linkedin`, `created`, `updated`, `type`, `approved`, `weight`) VALUES
(4, 'Amira Sowelem', 'Head Teacher', '<p>\r\n	<span style="font-size:16px;">With over 15 years of managerial, counseling and teaching experience, Ms. Sowelem has comprehensive knowledge of university requirements and the application process, local and abroad. She has the knowledge of current educational and research trends and has considerable insight of how international schools work within regulations set by Egypt&rsquo;s Ministry of Education.</span></p>\r\n', 'IMG_0373.JPG_3744d.jpg', 'amirasowelem@ethosedu.com', '', '2015-12-01 08:58:21', '2016-01-21 13:50:58', 0, 1, 3),
(5, 'Mai Mossad', 'Head of Foundation Stage', '<p>\r\n	<span style="font-size:16px;">Ms. Mossad received her BA from the American University in Cairo and later received her M.Ed from the American International College in Massachusetts. As an educator for more than 10 years and co-founder of Rukan Preschool, she worked as an early childhood and elementary teacher in both IB and American systems. She also managed and trained staff members.</span></p>\r\n', 'DSC_5662_c60e8.jpg', 'maimossad@ethosedu.com', '', '2015-12-01 09:04:23', '2015-12-07 14:30:09', 0, 1, 4),
(6, 'Youssra Raafat', 'Deputy General Manager', '<p>\r\n	<span style="font-size:16px;">With a BA from the Faculty of Law at the University of Alexandria, Ms. Rafaat co-founded Rukan Preschool. She has a vision to develop children&rsquo;s abilities using up-to-date techniques in a safe and friendly environment with the help of high-quality workforce. With exceptional standards of education, intricate parent-teacher communication and top-notch staff performance, Ms. Raafat promises very high levels of child care and development.</span></p>\r\n', 'IMG_5293.JPG_2b3ef.jpg', 'youssraraafat@ethosedu.com', '', '2015-12-01 09:05:54', '2016-01-12 14:22:43', 0, 1, 2),
(7, 'Muhammad Salah', 'General Manager', '<p>\r\n	<span style="font-size:16px;">Mr. Salah graduated from the Faculty of Engineering at the University of Alexandria. He started his career by founding a construction company and an agricultural company for exports. He then established Rukan Preschool and through Ethos International School, he continues to carry his personal vision of human development into all his projects, viewing the child as the raw material through which we can create change in our society today in order to serve our civil and humanitarian duties.</span></p>\r\n', 'IMG_5315.JPG_9f8d8.jpg', 'muhammadsalah@ethosedu.com', '', '2015-12-01 09:06:46', '2016-01-12 14:22:25', 0, 1, 1),
(9, 'Nohha Emad', 'Head of Character Education', '<p>\r\n	<span style="font-size:16px;">Ms. Emad, our Character Education Consultant, has received her M.Ed from the American University in Cairo along with an M.D. in Dentistry from Cairo University. She is a certified Character Education Specialist with a certification from the University of San Diego. She attended various courses in Child Development and Psychology and headed the Character Education Department and was the Behavioural Advisor in a renowned American School.&nbsp;</span></p>\r\n', 'IMG_5296.JPG_02520.jpg', 'nohhaemad@ethosedu.com', '', '2015-12-02 14:29:45', '2016-08-22 09:08:04', 0, 1, 7),
(10, 'Amira Gomaa', 'Head of Arabic Studies', '<p>\r\n	<span style="font-size:16px;">Ms. Gomaa graduated from the Faculty of Kindergarten Education. She worked in the educational field for more than 12 years. She founded and headed the Arabic Department in an IB school. She attended a range of IB and leadership courses and is passionate about the Arabic Language with a vision of creatively creating a curriculum that raises the skills and acquisition of children in Arabic.</span></p>\r\n', 'IMG_5316.JPG_835fc.jpg', 'amirali@ethosedu.com', '', '2015-12-06 15:08:40', '2015-12-21 12:25:36', 0, 1, 6),
(11, 'Yvonne Fisher', 'Head of Key Stage 1 & 2', '', 'Yvonne_Fisher_6525e.jpg', '', '', '2016-08-22 09:11:21', '2016-08-22 09:27:11', 0, 0, 5),
(12, 'Dalia Elguindy', 'Head of Expressive Arts', '<p>\r\n	<span style="font-size:16px;">A professional actress/singer with 16 years of performance experience and 8 years of teaching. Ms. Elguindy graduated from AUC with a bachelors degree in Theatre and is a member of the oldest independent theatre company in Egypt. She was theatrically trained under some of the top professionals in the industry both in Egypt and internationally. As a teacher, she was a Key Stage 1 team leader for three years, with experience in marketing, events management and directing. With years of experience in drama coordination, acting coaching and productions, Ms. Elguindy highly believes the arts shape the foundations of a child&#39;s personality and heightens their sense of humanity, responsibility and respect for society.&nbsp;</span></p>\r\n', 'Dalia_El_Guindy_ff951.jpg', 'daliaelguindy@ethosedu.com', '', '2016-08-22 09:23:46', '2016-08-22 09:47:09', 0, 1, 9),
(13, 'Reham Al Mellawani', 'Head of Learning Support', '<p>\r\n	<span style="font-size:16px;">Ms. Reham Al Mellawani is a child clinical psychologist who is licensed to conduct both cognitive and educational assessments. She has completed her Master of Arts degree in Child Clinical Psychology from Cairo University and her Master of Science from California Southern University.&nbsp; As the Head of a Learning Support Department, Ms. Reham is responsible for assessing, diagnosing, setting IEPs for students with disabilities and training both learning support and general education classroom teachers on how to use evidence-based interventions with students with disabilities. She has over 16 years&#39; experience in the education sector and in the field of special needs alongside her extensive experience in the field of assessment and diagnosis.&nbsp; Alongside counseling students with emotional/behavioral difficulties, training teachers, assessing and diagnosing students with disabilities, she is also a Neuro-linguistic Programming Trainer certified from the American Board of Neuro-Linguistic Programming and a certified hypnotherapist from the American Board of Hypnotherapy.&nbsp; She is a practitioner in Emotional Freedom Technique developed by Dr. Gary Craig and also a Time Line&reg; Therapist certified by the Time Line&reg; Therapy Association. &nbsp;</span></p>\r\n', '', 'rehamalmellawani@ethosedu.com', '', '2016-08-22 09:35:55', '2016-08-22 09:47:40', 0, 1, 8);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE IF NOT EXISTS `testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `body` text,
  `image` varchar(255) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `position`, `body`, `image`, `approved`, `featured`, `created`, `updated`, `weight`) VALUES
(1, 'Mohamed Elsayed', '', '<p>\r\n	Picking the right school initially was a difficult decision, especially when moving to a foreign country which Ireland was to us when we first moved to Dublin. Even though Dublin has a vast amount of citizens from all over the world, it always feels rather lonely to uproot your family.</p>\r\n', '214650552_6106d.jpg', 1, 0, '2015-11-13 04:20:30', '2015-11-13 04:20:30', 1),
(2, 'Mohamed Elsayed2', '', '<p>\r\n	Picking the right school initially was a difficult decision, especially when moving to a foreign country which Ireland was to us when we first moved to Dublin. Even though Dublin has a vast amount of citizens from all over the world, it always feels rather lonely to uproot your family.</p>\r\n', '214650552_6106d.jpg', 1, 0, '2015-11-13 04:20:30', '2015-11-13 04:42:34', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT '1',
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL,
  `confirm_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username_2` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `gender`, `email`, `image`, `username`, `password`, `group_id`, `confirm_code`) VALUES
(1, 'Mohamed Elsayed', 1, 'me@mohamedelsayed.net', '', 'elsayed', '860b44562bd0081f45bc363521b2fe26d8aa8977', 0, NULL),
(2, 'Mohamed Elsayed', 1, 'ethos@mohamedelsayed.net', '', 'admin', '88326122b923be10c6b1dbfe118867c886b15c49', 0, NULL),
(3, 'Shadden El Banna', 0, 'shadden.elbanna@gmail.com', '', 'shadden', 'fda64ff93948b8d7df8f3d69213f541839c4f92a', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `values`
--

CREATE TABLE IF NOT EXISTS `values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text,
  `image` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `values`
--

INSERT INTO `values` (`id`, `title`, `body`, `image`, `created`, `updated`, `weight`, `approved`) VALUES
(1, 'Fun', '', 'rukan_pic_value_75ea7.png', '2015-11-20 03:59:02', '2016-11-14 23:35:21', 1, 1),
(2, 'Love', '', 'rukan_pic2_value_42e00.png', '2015-11-20 04:40:25', '2016-11-14 23:36:37', 2, 1),
(3, 'Imagine', '', 'rukan_pic_i_value_b0300.png', '2015-11-20 04:41:12', '2016-11-14 23:37:06', 3, 1),
(4, 'Learn', '', 'rukan_pic_le_value_2a575.png', '2015-11-20 04:41:54', '2016-11-14 23:37:40', 4, 1),
(5, 'Grow', '', 'rukan_pic_gr_value_c18e2.png', '2015-11-20 04:42:20', '2016-11-14 23:38:15', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `hits` int(11) NOT NULL,
  `node_id` int(11) NOT NULL DEFAULT '0',
  `content_id` int(11) NOT NULL DEFAULT '0',
  `event_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE IF NOT EXISTS `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `title_ar` varchar(255) DEFAULT NULL,
  `body` longtext,
  `body_ar` longtext,
  `image` varchar(255) DEFAULT NULL,
  `page_id` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`id`, `title`, `title_ar`, `body`, `body_ar`, `image`, `page_id`, `approved`, `created`, `updated`) VALUES
(1, 'Home Image', '', '', '<p>\r\n	تست</p>\r\n', 'pic_rukan_home_55c7a.jpg', 1, 1, '2015-11-01 21:46:44', '2016-11-14 23:08:24'),
(2, 'Home Word #1', 'فلسفتنا', '<p>\r\n	Give your child a fun experience</p>\r\n<p>\r\n	in a safe environment</p>\r\n', '<p>\r\n	هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام &quot;هنا يوجد محتوى نصي، هنا يوجد محتوى نصي&quot; فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل افتراضي كنموذج عن النص، وإذا قمت بإدخال &quot;lorem ipsum&quot; في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.</p>\r\n', '', 1, 1, '2015-11-02 00:29:19', '2016-11-14 22:38:39'),
(3, 'Home Word #2', NULL, '<p>\r\n	caring and nurturing</p>\r\n<p>\r\n	environment to help develop</p>\r\n<p>\r\n	children holistically.</p>\r\n', NULL, '', 1, 1, '2016-11-14 22:34:21', '2016-11-14 23:09:19'),
(4, 'our values', NULL, '', NULL, '', 1, 1, '2016-11-14 23:31:20', '2016-11-14 23:31:20');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
